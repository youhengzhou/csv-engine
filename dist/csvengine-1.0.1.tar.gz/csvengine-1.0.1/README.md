# CSV Engine

please refer to `https://pypi.org/project/csvengine/` for the python package

and please refer to `https://github.com/youhengzhou/csv-engine` for the repo

# Download Package

`py -m pip install csvengine -U`

## In Your Python Files

`import csvengine.main as eng`
